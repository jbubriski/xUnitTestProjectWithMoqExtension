﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xunit;
using Moq;

namespace $safeprojectname$
{
    public class xUnitTest
    {
        public xUnitTest()
        {

        }

        [Fact]
        public void Test( )
        {
            
        }
    }
}
